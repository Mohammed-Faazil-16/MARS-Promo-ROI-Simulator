"""FastAPI dependencies."""
