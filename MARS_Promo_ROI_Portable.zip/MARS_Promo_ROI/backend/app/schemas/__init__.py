"""Pydantic API schemas."""
